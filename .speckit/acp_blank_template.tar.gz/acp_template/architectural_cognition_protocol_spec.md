# Architectural Cognition Protocol (ACP)
## A Model-Oriented Reasoning Protocol for Complex Software Analysis

The **Architectural Cognition Protocol (ACP)** is a formal reasoning protocol designed for AI-assisted software analysis. Unlike traditional answer-oriented prompt frameworks (which follow a static $\text{Question} \rightarrow \text{Reasoning} \rightarrow \text{Answer}$ loop), ACP is **model-oriented** and **epistemic**. It treats software analysis as the progressive refinement of an internal, self-correcting knowledge graph of the target system:

$$\text{Evidence} \rightarrow \text{Architectural Model} \rightarrow \text{Challenge} \rightarrow \text{Counter-Evidence} \rightarrow \text{Revised Model} \rightarrow \text{Confidence Update}$$

---

## 1. Core Axiom

### The Architectural Cognition Principle
> Every execution-derived signal should have a complete, verifiable lifecycle: **production $\rightarrow$ transport $\rightarrow$ ownership $\rightarrow$ persistence $\rightarrow$ consumption $\rightarrow$ optimization**. Any discontinuity in that lifecycle represents an architectural defect, regardless of whether the software compiles or passes conventional tests.

---

## 2. Epistemic Knowledge Objects

The cognition graph is composed of six persistent object types:

### 2.1 Fact (`FACT-[ID]`)
An immutable, verified structural or behavioral observation backed by direct, source-level citations.
*   **Fields**:
    *   `ID`: Unique identifier (e.g., `FACT-001`).
    *   `Source`: File path and exact line number range.
    *   `Description`: Technical description of the code behavior or layout.

### 2.2 Hypothesis (`HYP-[ID]`)
An architectural assumption or belief that is plausible but not yet proven.
*   **Fields**:
    *   `ID`: Unique identifier.
    *   `Claim`: The architectural assertion.
    *   `Confidence`: Estimated probability of correctness ($0.0$ to $1.0$).
    *   `Verification Plan`: Specific file traces, command runs, or tests planned to prove or refute the claim.

### 2.3 Invariant (`INV-[ID]`)
A semantic, logical, or temporal guarantee that the system must satisfy to ensure correctness or loop integrity.
*   **Fields**:
    *   `ID`: Unique identifier.
    *   `Definition`: The rule or property that must hold true.
    *   `Regression Coverage`: Clickable links to the unit or integration tests enforcing this rule.

### 2.4 Contradiction (`CON-[ID]`)
A mismatch between a model claim/hypothesis and new source code evidence. Contradictions are never overwritten; they are logged permanently to drive the next iteration.
*   **Fields**:
    *   `ID`: Unique identifier.
    *   `Conflict`: Description of how the evidence contradicts the model.
    *   `Source Evidence`: Clickable link to the disproving code/behavior.

### 2.5 Confidence Matrix (`CONF-[ID]`)
A structured metric evaluating the strength of an architectural claim based on supporting evidence.
*   **Formula**:
    $$\text{Confidence Score} = f(\text{Source Checks}, \text{Trace Audits}, \text{Passing Tests})$$

### 2.6 Assumption (`ASSUMPTION-[ID]`)
An active model assumption whose verification status is tracked over time.
*   **Fields**:
    *   `ID`: Unique identifier.
    *   `Statement`: The assumption statement.
    *   `Status`: `Pending` | `Verified` | `Refuted`.
    *   `Evidence/Result`: Clickable link to the verification trace or resulting failure classification.

---

## 3. The Self-Driving Iteration Loop

Every iteration cycle in the protocol executes a deterministic pipeline:

```mermaid
graph TD
    CollectFacts["1. Collect Facts (Citations)"] --> UpdateModel["2. Update Architectural Model"]
    UpdateModel --> FindContradictions["3. Find Contradictions"]
    FindContradictions --> GenerateHypotheses["4. Generate Hypotheses"]
    GenerateHypotheses --> PrioritizeByRisk["5. Prioritize by Risk"]
    PrioritizeByRisk --> TraceVerify["6. Trace & Verify"]
    TraceVerify --> UpdateConfidence["7. Update Confidence & Entropy"]
    UpdateConfidence --> LoopCondition{"Entropy < Threshold?"}
    LoopCondition -- Yes --> EndAudit["8. End Audit"]
    LoopCondition -- No --> CollectFacts
```

---

## 4. Quantitative Heuristic: Architectural Entropy

To determine the stopping condition of an analysis campaign objectively, the protocol defines **Architectural Entropy ($H_A$)**, representing the volume of structural and behavioral uncertainty in the system:

$$H_A = \sum (w_i \cdot U_i)$$

### 4.1 Heuristic Weights ($w_i$)
The entropy contribution of each unresolved uncertainty is weighted according to its architectural severity:

| Uncertainty Type ($U_i$) | Weight ($w_i$) | Description |
|---|---|---|
| **Unknown Producer** | $1$ | A signal destination exists, but its producer is unidentified. |
| **Unknown Consumer** | $1$ | A signal is produced, but its consumption pathway is unidentified. |
| **Unverified Invariant** | $2$ | An invariant exists but lacks active regression test coverage. |
| **Untested Control Edge** | $3$ | A control-flow pathway has not been exercised via unit testing. |
| **Lifetime Ambiguity** | $3$ | A signal's persistence window or deletion lifecycle is undefined. |
| **Ownership Ambiguity** | $3$ | A signal is bound to an incorrect scope or abstraction level. |
| **Objective Disconnect** | $5$ | The optimizer optimizes a different function than the oracle measures. |
| **Contradictory Evidence** | $5$ | New evidence directly conflicts with the current model's invariants. |

### 4.2 Stopping Condition
The protocol terminates when:
$$H_A < \theta$$
*(Where $\theta$ is the user-defined maximum acceptable entropy threshold, typically $\theta \le 10$).*

---

## 5. Three-Layer Taxonomy of Architectural Failures

To prevent ad-hoc naming of discovered defects, the protocol classifies all vulnerabilities across three distinct abstraction layers:

### Layer 1 — Information Defects (What happened to the information)
*   **Lifetime Failure (Temporal Mismatch)**: A signal survives too long or leaks across execution boundaries (violates the *Execution Locality Principle*).
*   **Transport Failure (Information Flow Mismatch)**: A signal is lost or truncated in transit between modules (violates the *Execution Reconstructibility Invariant*).
*   **Transformation Failure**: A signal is degraded or loses resolution during boundary translation.
*   **Consumption Failure (Dead Telemetry)**: A signal is actively produced and persisted, but never read by any downstream module.

### Layer 2 — Control Defects (Why the defect happened)
*   **Ordering Failure**: Operations are executed in an incorrect or vulnerable sequence.
*   **Ownership Failure**: A signal is bound to the wrong abstraction scope (e.g., process-global static mut instead of testcase-local metadata).
*   **Synchronization Failure**: Concurrent execution or state-pranks pollute isolated states.
*   **Visibility Failure**: Internal boundaries restrict a module from accessing the required signal.

### Layer 3 — Optimization Defects (Closed-loop failures)
*   **Gradient Failure**: An optimization signal exists, but has no usable slope (e.g., flat gradients).
*   **Objective Mismatch**: The optimizer targets a different objective than the oracle measures.
*   **Reward Sparsity**: The feedback signal is too infrequent to guide exploration.
*   **Signal Compression**: An objective's magnitude is reduced to a binary boolean (loss of gradient resolution).
*   **Signal Dominance**: One objective function completely overwhelms and starves another.

---

## 6. Issue Remediation Format

Any behavioral defect or loop gap discovered during the protocol must be reported as a first-class cognition object using the following template:

*   **Invariant Violated**: Link to `INV-[ID]`.
*   **Evidence**: Cite the exact file, line number, and variables.
*   **Impact on Feedback Loop**: Explain how the defect causes a "silent capability death" or distorts fuzzer exploration.
*   **Patch**: The code modification applied.
*   **Verification**: Command outputs or tests confirming the fix.
*   **Architectural Lesson**: The root cause explanation ("Why" the bug existed at the system design level).
