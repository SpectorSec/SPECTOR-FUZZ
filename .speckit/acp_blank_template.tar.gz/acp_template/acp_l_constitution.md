# The ACP-L V4 Execution Constitution
## The Prescriptive Playbook for Architectural Rigor

This Constitution defines the immutable rules and step-by-step procedures for executing the **Architectural Cognition Protocol Lifecycle V4 (ACP-L V4)**. It is designed to be highly prescriptive, leaving zero room for shortcuts, code hacking, or semantic deviations. 

---

## The Core Commandment
> **The Architectural Knowledge Graph is the single source of truth; the code is merely its projection. You are forbidden from writing a single line of implementation code until its contract has been formally registered in the graph.**

---

## Part 1: Immutable Rules of Engagement

1.  **Strict Phase Linearity**: You are forbidden from skipping or jumping phases. You cannot write a Specification without an Intent, you cannot write Code without a Contract, and you cannot Merge without an Audit.
2.  **No Unmapped Signals**: Every variable, buffer, or objective function that crosses a module boundary must be declared as a typed `Signal` with explicit ownership and lifetime bounds.
3.  **No Blind Commits**: Every code commit must be formatted as an **Architectural Event** mapping directly to graph changes (Facts, Assumptions, Invariants, and ADRs).
4.  **Zero-Tolerance Review**: Any pull request that increases Architectural Drift ($\Delta > 0.05$), introduces Lifetime leaks, or bypasses the Canonical Review Checklist must be **rejected immediately**.

---

## Part 2: Step-by-Step Execution Playbook

Follow this sequence from beginning to end for every development cycle or feature insertion:

```mermaid
graph TD
    Start[Start Campaign] --> Phase0[Step 0: Discovery - ACP-D]
    Phase0 --> Phase1[Step 1: Scoping Intent]
    Phase1 --> Phase2[Step 2: Executing Contracts]
    Phase2 --> Phase3[Step 3: Staging Constraints]
    Phase3 --> Phase4[Step 4: Implementation]
    Phase4 --> Phase5[Step 5: Pull Request Review]
    Phase5 --> Phase6[Step 6: Evolution & Convergence]
    Phase6 --> End[End Campaign]
```

### Step 0: Discovery (ACP-D) — *For Existing Systems*
If you are starting on an existing codebase, you must first discover the baseline architecture before modifying it.
1.  **Trace Codebase**: Scan the source code to locate all active components, entry points, and database scopes.
2.  **Map Signals**: Identify all variables or parameters that act as objectives, feedbacks, or transport channels.
3.  **Construct Capability Graph**: Group these signals into functional domains (Capabilities).
4.  **Log Assumptions**: Write down everything you believe to be true about the system's execution pathways as `ASSUMPTION` objects with `E0` evidence.
5.  **Run Triage**: Verify assumptions using code traces and compilation tests to promote them to `FACT` or refute them as `CON`.

### Step 1: Scoping Intent
Define the change before designing the code. Answer these 5 questions in writing:
1.  *Why does this change exist?*
2.  *Which Capability Graph does it modify or add?*
3.  *Which architectural loops are changed?*
4.  *Which optimization loops are changed?*
5.  *Which invariants does it touch or inherit?*

### Step 2: Executing Contracts (ACP-P)
Write the formal specification in YAML format. Do not write Rust/TS code yet.
1.  Define the **Identity** of the components.
2.  Map the **Information Flow** (Producers, Transport, Storage, Consumers, Optimizers).
3.  Bind the **Lifetime** boundaries (Created, Mutated, Destroyed).
4.  Enforce the **Control & Ordering** constraints.

### Step 3: Staging Constraints & Decisions
Prepare the validation rules:
1.  Write the formal constraints (`INV` objects) that verify the contract's guarantees.
2.  Log the design choices as an Architectural Decision Record (`ADR` object), detailing alternative approaches and why they were rejected.
3.  Verify that `Spec Entropy (H_Spec) = 0` (every invariant must have a test case planned).

### Step 4: Implementation (Satisfying Contracts)
Now you may write the code.
1.  **Write Tests First**: Implement unit and integration tests that assert the constraints defined in Step 3.
2.  **Write Code**: Implement the functional logic to pass the tests.
3.  **Commit as Events**: Format every git commit message to specify:
    *   *Facts changed* (`FACT-[ID]`)
    *   *Invariants changed* (`INV-[ID]` with updated Evidence Grid status)
    *   *Assumptions changed* (`ASSUMPTION-[ID]`)
    *   *Drift / Entropy Delta* ($\Delta H_A$ and $\Delta_{structural}$)

### Step 5: Pull Request Review (The Architectural Gate)
Perform code review using the **Canonical Review Checklist**. The reviewer must verify:
*   *Signals*: Ownership, lifetime, and typing.
*   *Information*: Lossless transport, resolution preservation, and reconstruction capability.
*   *Control*: Determinism, sync state, and stale-read protection.
*   *Optimization*: Gradient availability and objective alignment.

### Step 6: Evolution & Convergence
Once code passes review and is merged:
1.  **Recalculate CMI**: Verify the Capability Maturity Index (Target: Specification = 100%, Contradictions = 0, Confidence $\ge$ 0.95).
2.  **Verify Drift**: Assert that both $\Delta_{structural}$ and $\Delta_{semantic}$ remain below 0.05.
3.  **Feedback Constraint Propagation**: Convert lessons learned during implementation/testing into permanent, inherited invariants for all future specs.
