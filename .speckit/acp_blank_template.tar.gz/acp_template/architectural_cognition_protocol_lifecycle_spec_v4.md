# Architectural Cognition Protocol Lifecycle V4 (ACP-L V4)
## A Formal Ontological & Graph-Based Systems Engineering Framework

The **Architectural Cognition Protocol Lifecycle V4 (ACP-L V4)** is a formal systems engineering methodology. It unifies software design, development, verification, and evolution by representing software architecture as a **directed graph of capabilities connected by information-bearing signals**.

---

## 1. The Core Ontological Core

To prevent conceptual sprawl, all components of the system design and cognition are derived from a minimal set of seven base ontological entities:

```mermaid
graph TD
    Entity --> Capability["Capability (Functional Domain)"]
    Entity --> Signal["Signal (Information-bearing Channel)"]
    Entity --> Contract["Contract (Interface Boundary)"]
    Entity --> Evidence["Evidence (Verification Dimension)"]
    Entity --> Decision["Decision (ADR)"]
    Entity --> Observation["Observation (Findings)"]
    Entity --> Constraint["Constraint (Invariants)"]
```

### Derived Concepts
*   **Invariant (`INV`)** $\equiv$ `Constraint` (Guarantees that must hold true).
*   **Architectural Decision Record (`ADR`)** $\equiv$ `Decision` (Rationale for graph modifications).
*   **Fact (`FACT`)** $\equiv$ `Observation` + `Evidence` (Verified structural/behavioral observations).
*   **Assumption (`ASSUMPTION`)** $\equiv$ `Observation` lacking `Evidence` (Unverified design beliefs).
*   **Contradiction (`CON`)** $\equiv$ `Constraint` violation (Mismatch between observation and constraints).

---

## 2. Signals as First-Class Objects

Every information channel, objective function, variable, or buffer is modeled as a typed **Signal** with a bounded lifecycle:

```yaml
signal:
  id: SIG-031
  name: "invariant_gradient"
  type: "u128"
  producer: "invariant_oracle"
  transport: "thread_local"
  owner: "testcase"
  consumer: "secant_mutator"
  lifetime: "execution"
  optimization: "continuous"
  constraints:
    - "execution_local"
    - "non_stale"
```

---

## 3. Structural vs. Semantic Drift

Architectural Drift ($\Delta$) is divided into two independent, measurable metrics:

### 3.1 Structural Drift ($\Delta_{structural}$)
Measures changes in the topology of the capability graph (edges, components, or modules):
$$\Delta_{structural} = \frac{\text{Unmapped Edges} + \text{Orphaned Signals}}{\text{Total Configured Capability Edges}}$$

### 3.2 Semantic Drift ($\Delta_{semantic}$)
Measures changes in the data type, magnitude resolution, or meaning of signals across existing edges:
$$\Delta_{semantic} = \frac{\text{Type Mismatches} + \text{Gradient Resolution Reductions}}{\text{Total Configured Capability Edges}}$$

---

## 4. Capability Maturity Index (CMI)

Every capability graph is evaluated using a normalized **Capability Maturity Index (CMI)**:

| CMI Attribute | Metric Formula / Definition | Target |
|---|---|---|
| **Specification** | % of signals/interfaces bound to explicit Contracts. | $100\%$ |
| **Evidence** | % of Invariants verified by $\ge \text{E3}$ (test) evidence. | $\ge 90\%$ |
| **Drift** | Combined $\Delta_{structural} + \Delta_{semantic}$ score. | $\le 5\%$ |
| **Test Coverage** | Code line coverage of all associated components. | $\ge 90\%$ |
| **Contradictions** | Number of active unresolved `CON-[ID]` objects. | $0$ |
| **Confidence** | Average confidence score of assumptions. | $\ge 0.95$ |

---

## 5. Architectural Query Interface (AQI)

ACP-L V4 graphs are fully searchable using structural graph queries to verify invariants programmatically:

*   **Orphan Search**: `g.V().hasLabel('Signal').not(inE('consumes'))`
*   **Scope Leak Check**: `g.V().hasLabel('Signal').has('lifetime', 'execution').has('transport', 'process_global')`
*   **Gradient Flow Audit**: `g.V().hasLabel('Optimizer').not(outE('reads').hasLabel('Signal').outE('produces'))`

---

## 6. Epistemic Separation: Discovery (ACP-D) vs. Prescription (ACP-P)

ACP-L V4 strictly decouples reverse engineering from forward design:

```text
       ACP-D (Discovery Phase)                    ACP-P (Prescription Phase)
       
   Source Code & Tests (Evidence)               Architectural Intent & Capabilities
               │                                              │
               ▼                                              ▼
    Verify / Build Real Graph                    Define Executable Contracts (ADL)
               │                                              │
               └──────────────────────┬───────────────────────┘
                                      │
                                      ▼
                        Graph Alignment (Semantic Check)
                                      │
                                      ▼
                       Drift & Contradiction Logging
```

---

## 7. Canonical Review Checklist

All feature pull requests must answer the 12 canonical questions before merge:

### 7.1 Signals
1.  *What new signals are introduced, and what are their types?*
2.  *Which module owns their storage lifecycle?*
3.  *What is their exact persistence window (lifetime)?*

### 7.2 Information
4.  *Can the execution state be fully reconstructed from the transport logs?*
5.  *Is signal transport lossless across component boundaries?*
6.  *Does translation degrade signal resolution or magnitude?*

### 7.3 Control
7.  *Is execution ordering deterministic across callbacks?*
8.  *Are stale reads prevented during execution bounds?*
9.  *Are concurrent state updates isolated?*

### 7.4 Optimization
10. *Does the planner schedule inputs based on the signal?*
11. *Does the mutator receive a non-zero gradient for all parameters?*
12. *Is the optimization target aligned with the oracle measurement?*
